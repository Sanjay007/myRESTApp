myApp.controller('MenuCntrl', ['$scope', '$window', '$location', 'AuthenticationFactory',
  function($scope, $window, $location,  AuthenticationFactory) {


}
]);
